"""Long, fully funded positions. Every value in the ledger is USD."""

import math
import pandas as pd


def usd(symbol, change, mark):
    return change / mark if symbol.startswith("USD/") else change


def fee(c, s, price):
    return usd(s, price, price) * c["fee_bps"] / 10000


def result(c, s, entry, exit_price):
    return (
        usd(s, exit_price - entry, exit_price)
        - fee(c, s, entry)
        - fee(c, s, exit_price)
    )


def new_account(c):
    initial = c["equity"]
    return dict(
        balance=initial,
        equity=initial,
        peak=initial,
        day_start=initial,
        day="",
        halted=False,
        day_halt=False,
        positions={},
        cursor=None,
    )


def limits(c, a, t, equity):
    day = str(pd.Timestamp(t).date())
    if a["day"] != day:
        a.update(day=day, day_start=a["equity"], day_halt=False)
    a["peak"] = max(equity, a["peak"])
    a["halted"] |= bool(equity <= a["peak"] * (1 - c["drawdown"]))
    a["day_halt"] |= bool(equity <= a["day_start"] * (1 - c["daily_loss"]))
    a["equity"] = equity


def correlated(c, s, positions, frames, t):
    for other in positions:
        prices = pd.concat(
            [frames[k].close.loc[:t] for k in (s, other)], axis=1, join="inner"
        )
        changes = prices.pct_change(fill_method=None).tail(c["corr_window"])
        rho = changes.iloc[:, 0].corr(changes.iloc[:, 1])
        if (
            len(changes.dropna()) < c["corr_window"]
            or not math.isfinite(rho)
            or abs(rho) >= c["correlation"]
        ):
            return True
    return False


def plan(c, a, s, entry, atr, free):
    if (
        a["halted"]
        or a["day_halt"]
        or len(a["positions"]) >= c["max_positions"]
        or s in a["positions"]
    ):
        return None
    stop = entry - c["atr_stop"] * atr
    slip = c["slip_bps"] / 10000
    if not 0 < stop < entry:
        return None
    loss = -result(c, s, entry, stop * (1 - slip))
    budget = min(
        a["equity"] * c["risk"],
        a["equity"] - a["day_start"] * (1 - c["daily_loss"]),
        a["equity"] - a["peak"] * (1 - c["drawdown"]),
    )
    unit = usd(s, entry, entry)
    step = c["symbols"][s]
    qty = math.floor(min(budget / loss, free / (unit + fee(c, s, entry))) / step) * step
    if qty <= 0:
        return None
    # Solve net exit proceeds analytically, including USD-base FX conversion.
    f = c["fee_bps"] / 10000
    required = loss * c["reward"]
    if s.startswith("USD/"):
        if required + 2 * f >= 1:
            return None
        target = entry / (1 - required - 2 * f)
    else:
        target = (entry * (1 + f) + required) / (1 - f)
    return dict(entry=entry, qty=qty, stop=stop, target=target, capital=qty * unit)
