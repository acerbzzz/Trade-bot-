"""Chronological holdout; independent fresh portfolio for the scored period."""

import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from config import load, MINUTES
from engine import advance, close
from exchange import normalize
from risk_manager import new_account
from strategies import prepare


def aligned(frames):
    index = next(iter(frames.values())).index
    if any(not d.index.equals(index) for d in frames.values()):
        raise ValueError(
            "Unequal candle calendars. Repair missing bars before running."
        )
    return index


def evaluate(c, frames, out):
    index = aligned(frames)
    start = max(c["history"], int(len(index) * (1 - c["holdout"])))
    if start >= len(index) - 1:
        raise ValueError("Too few bars for warmup and holdout")
    a = new_account(c)
    rows = []
    trades = []
    for t in index[start:]:
        _, closed = advance(c, a, frames, t)
        trades.extend(closed)
        rows.append((t, a["equity"]))
    for s in list(a["positions"]):
        trades.append(
            close(
                c,
                a,
                s,
                frames[s].at[t, "close"] * (1 - c["slip_bps"] / 10000),
                t,
                "end_of_test",
            )
        )
    rows[-1] = (t, a["balance"])
    baseline = index[start] - pd.Timedelta(minutes=MINUTES[c["timeframe"]])
    curve = pd.Series(dict([(baseline, c["equity"]), *rows]), name="equity")
    log = pd.DataFrame(
        trades, columns="symbol opened closed qty entry exit pnl reason".split()
    )
    gain = log.pnl.clip(lower=0).sum()
    loss = -log.pnl.clip(upper=0).sum()
    daily = curve.resample("D").last().dropna()
    rets = (
        pd.concat(
            [pd.Series([c["equity"]]), daily.reset_index(drop=True)], ignore_index=True
        )
        .pct_change()
        .dropna()
    )
    periods = 365 if c["market"] == "crypto" else 252
    stats = dict(
        start=str(index[start]),
        end=str(t),
        closed=len(log),
        final_equity=a["balance"],
        win_rate=float((log.pnl > 0).mean()) if len(log) else None,
        profit_factor=float(gain / loss) if loss else None,
        max_drawdown=float((1 - curve / curve.cummax()).max()),
        sharpe=float(rets.mean() / rets.std() * np.sqrt(periods))
        if len(rets) > 1 and rets.std() > 0
        else None,
        expectancy_usd=float(log.pnl.mean()) if len(log) else None,
    )
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    curve.to_csv(out / "equity.csv", index_label="timestamp")
    log.to_csv(out / "trades.csv", index=False)
    (out / "metrics.json").write_text(json.dumps(stats, indent=2, allow_nan=False))
    return stats


def demo(c):
    rng = np.random.default_rng(761)
    index = pd.date_range(
        "2024-01-01", periods=1600, freq=f"{MINUTES[c['timeframe']]}min", tz="UTC"
    )
    frames = {}
    for s in c["symbols"]:
        close_px = 100 * np.exp(rng.normal(0.00005, 0.006, len(index)).cumsum())
        op = np.r_[close_px[0], close_px[:-1]]
        d = pd.DataFrame(
            dict(
                open=op,
                high=np.maximum(op, close_px) * 1.002,
                low=np.minimum(op, close_px) * 0.998,
                close=close_px,
                volume=rng.integers(10, 200, len(index)),
            ),
            index=index,
        )
        frames[s] = prepare(d, c)
    return frames


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/crypto.yml")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--demo", action="store_true")
    group.add_argument("--data", type=Path)
    ap.add_argument("--out", default="output")
    args = ap.parse_args()
    c = load(args.config)
    frames = (
        demo(c)
        if args.demo
        else {
            s: prepare(
                normalize(pd.read_csv(args.data / (s.replace("/", "_") + ".csv"))), c
            )
            for s in c["symbols"]
        }
    )
    print(json.dumps(evaluate(c, frames, args.out), indent=2))
