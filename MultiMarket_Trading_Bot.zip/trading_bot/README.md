# Multi-market trading bot
A Python 3.11+ framework for closed-candle signals, fully funded long positions and chronological portfolio tests. The examples start with a separate $200 simulated USD account per market. No process starts on installation.

## First run
Extract the archive, open a terminal in the extracted trading_bot folder, then run:

```sh
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell uses .\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-feeds.txt
python -m unittest discover -s tests -v
python backtester.py --demo --config configs/crypto.yml
python bot.py --config configs/crypto.yml
```

The demo works offline after installation. It uses deterministic synthetic candles to verify the pipeline. The bot command polls a real feed and records simulated executions locally. Leave the terminal running. Ctrl+C stops it. Add --once for a single connectivity and initialization check. The first successful poll sets a cursor. A trade requires a later eligible signal and bar. Use an exchange available for your account and region.

| Profile | Source | Execution available |
|---|---|---|
| crypto.yml | CCXT Binance or Bybit spot OHLCV | Local paper |
| stocks.yml | Alpaca stock historical bars, IEX feed | Local paper |
| forex.yml | OANDA midpoint candles | Local paper, OANDA practice, explicitly confirmed OANDA live |

For stocks set APCA_API_KEY_ID and APCA_API_SECRET_KEY. For forex set OANDA_TOKEN for the environment you chose. Broker-backed OANDA modes also require OANDA_ACCOUNT_ID. Store credentials in the shell environment. Set notify to true and DISCORD_WEBHOOK_URL to receive fills and cycle errors. The notifier is best effort. The account ledger is authoritative.

## Signals
All four modules enter long. Each uses the previous completed bar for a paper entry at the following open. Indicators use causal rolling or exponentially weighted windows.

| YAML strategy | Enter | Discretionary exit |
|---|---|---|
| trend | Fast EMA crosses above slow EMA, ADX reaches threshold | Fast EMA below slow |
| reversion | Close below lower Bollinger band, RSI below oversold threshold | Close reaches band mean or RSI reaches recovery level |
| breakout | Close above prior Donchian high plus ATR buffer, volume exceeds prior mean times multiplier | Close below prior channel midpoint |
| momentum | MACD histogram crosses above zero and RSI reaches momentum threshold | Negative histogram or RSI below 50 |

Every entry also has a fixed ATR stop and net reward target. A discretionary exit can realize a smaller gain or loss. Forex volume is quote activity. A stock signal uses the selected feed's bars, including extended sessions when present. No short sales, options, leverage or automatic parameter fitting.

## Risk and portfolio accounting
Default risk budget is 0.75% of marked equity ($1.50 initially). The configuration accepts 0.5–1%. The engine divides the affordable planned loss by the loss per unit at an adverse stop fill, caps notional at available funds, then rounds quantity down to the configured increment. A $200 whole-share stock account can legitimately skip every signal in an expensive instrument. The risk budget sets a ceiling; actual usage can be smaller.

The target solves for at least 2.5 times planned loss after modeled entry/exit fees and stop slippage. Gaps, wider spreads and discontinuous markets can produce larger actual losses. Daily and peak drawdown thresholds block new entries when sampled equity breaches them. Existing positions keep their exits. Daily loss latches until the next UTC date, relative to the previous observed equity. Maximum drawdown latches across restarts. Paper checks opening and closing marks; broker mode checks NAV each cycle. Intrabar portfolio drawdown can exceed the observed drawdown. Concurrent positions can lose together.

The correlation filter uses absolute Pearson correlation of aligned close-to-close returns against each open position. It blocks candidates with inadequate overlapping history or undefined correlation. Symbols are considered in YAML order. USD/JPY profits and losses are converted at the exit mark. USDT is valued at one USD. The paper simulator uses configurable lot increments and flat costs; venue minimum notional, queue position, taxes, funding, FX rollover, dividends, splits and partial fills are outside the model.

## Configure
Edit one profile per account. config.py contains the complete default values, accepted keys and validation. Example overrides:

```yaml
strategy: breakout
params: {channel: 30, volume_ratio: 1.4, breakout_atr: 0.15}
timeframe: 15m
history: 300
poll_seconds: 30
fee_bps: 5
slip_bps: 3
corr_window: 40
holdout: 0.30
state: state/crypto-breakout-paper.sqlite
```

Supported timeframes are 5m, 15m and 1h. Add symbols under symbols with the allowed quantity increment. FX pairs must include USD. To add a strategy, implement signals(frame, params) in strategies/ returning two boolean Series, register its name and validated defaults in config.py, then run the causality and replay checks.

## Backtest your own history
Supply one CSV per configured symbol. BTC/USDT maps to BTC_USDT.csv. Include timestamp,open,high,low,close,volume with UTC bar-open timestamps, consistent bar duration, sorted market sessions and identical calendars across symbols. Use sufficient history for warmup plus evaluation. Check data for feed outages, corporate actions and timezone accuracy before interpreting the result.

```sh
python backtester.py --config configs/forex.yml --data ./candles --out ./results
```

The final holdout fraction is scored with a fresh portfolio. Earlier history warms indicators. No optimizer selects parameters or trains on the holdout. All symbols share one cash balance. Open gaps through stops fill at the adverse open with slippage; favorable target gaps fill at the limit. A bar touching both exits takes the stop first. Remaining positions close at the final mark less modeled costs.

Exports include equity.csv (USD marks), trades.csv (closed trades with reasons and net P&L) and metrics.json. Win rate is the profitable fraction of closed trades. Profit factor divides gross net-trade gains by absolute net-trade losses. Expectancy is mean net USD per closed trade. Maximum drawdown measures baseline and closing equity. Sharpe uses observed daily returns, zero risk-free rate, and 365 annual periods for crypto or 252 for stocks/FX. An undefined metric is JSON null. Synthetic test metrics supply no evidence of a trading edge.

## Operations and broker-backed execution
Keep the SQLite database and lock on local durable disk. One process owns a ledger. State and fill events commit together per paper cycle. Console and rotating file logs are written beside the database. Config changes require an explicit ledger choice. Avoid opening a second ledger on the same broker account. Retain the current ledger across restarts to preserve risk history. Back up while stopped.

Local paper models fills after the bar closes; it cannot establish an executable price or fill. The poller catches up existing paper positions and restricts new entries to the latest freshly closed interval. If the cursor falls outside history or symbol calendars disagree, processing pauses. Recover missing historical data before resuming. Treat prolonged outages or unreconciled gaps as breaks in the evaluation record.

For OANDA, use a dedicated USD account. Configure mode: practice first. Start with a fresh practice ledger. Broker mode sizes from actual account NAV and submits at most one broker action per signal bar, with a bounded FOK entry and attached stop-loss and take-profit. It checks pending orders and open trades before acting. Broker-side stops remain in place between polls. Test fill behavior, local account restrictions, restart recovery and exits on practice before considering live use. Confirm OANDA account suitability for trade client extensions. Broker conversion, financing, commission and execution can differ from the model.

Live mode requires mode: live, live credentials, and typing LIVE followed by the exact account ID at an interactive prompt on every start. Using --once in live mode can submit an order. The paper profiles never submit broker orders.

Before a broker write, an intent is committed. A timeout, cancellation or ambiguous response leaves that intent in place and blocks future writes. Stop the bot, inspect the orders, trades and transaction history at OANDA, compare the pending intent and resolve exposure or protection at the broker. Back up the database. Only after independently reconciling the outcome should an operator clear the account JSON's intent field in a transaction, preserving cursor, drawdown and remaining state. Never retry an ambiguous entry by deleting the ledger.

## Reference interfaces
- [CCXT Manual](https://github.com/ccxt/ccxt/wiki/Manual)
- [Alpaca historical stock data](https://alpaca.markets/sdks/python/api_reference/data/stock/historical.html)
- [OANDA v20 orders](https://developer.oanda.com/rest-live-v20/order-df/)
- [OANDA v20 pricing](https://developer.oanda.com/rest-live-v20/pricing-df/)
