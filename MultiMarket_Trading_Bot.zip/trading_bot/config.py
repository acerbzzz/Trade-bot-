"""One YAML describes one isolated USD portfolio."""

from pathlib import Path
import math
import yaml

DEFAULT = dict(
    mode="paper",
    strategy="trend",
    equity=200,
    timeframe="15m",
    risk=0.0075,
    reward=2.5,
    atr_period=14,
    atr_stop=2,
    max_positions=2,
    daily_loss=0.03,
    drawdown=0.10,
    correlation=0.80,
    corr_window=40,
    fee_bps=5,
    slip_bps=3,
    history=300,
    poll_seconds=30,
    holdout=0.30,
    notify=False,
    params={},
)
MARKETS = {"crypto": ("binance", "bybit"), "stocks": ("alpaca",), "forex": ("oanda",)}
MINUTES = {"5m": 5, "15m": 15, "1h": 60}
PARAMS = dict(
    fast=12,
    slow=26,
    adx=14,
    strength=20,
    bands=20,
    deviations=2,
    rsi=14,
    oversold=30,
    recovery=50,
    channel=20,
    volume_ratio=1.2,
    breakout_atr=0.1,
    signal=9,
    momentum=55,
)


def load(path):
    raw = yaml.safe_load(Path(path).read_text())
    unknown = set(raw) - set(DEFAULT) - {"market", "venue", "symbols", "state"}
    if unknown:
        raise ValueError(f"Unknown settings {unknown}")
    c = DEFAULT | raw
    if c["venue"] not in MARKETS[c["market"]] or c["timeframe"] not in MINUTES:
        raise ValueError("Unsupported venue or timeframe")
    if c["mode"] not in ("paper", "live", "practice") or c["strategy"] not in (
        "trend",
        "reversion",
        "breakout",
        "momentum",
    ):
        raise ValueError("Unknown mode or strategy")
    if set(c["params"]) - set(PARAMS):
        raise ValueError("Unknown strategy parameter")
    c["params"] = PARAMS | c["params"]
    for k in ("fast", "slow", "adx", "bands", "rsi", "channel", "signal"):
        if type(c["params"][k]) is not int or not 2 <= c["params"][k] <= 200:
            raise ValueError(k)
    p = c["params"]
    if not (
        p["fast"] < p["slow"]
        and 0 < p["oversold"] < p["recovery"] < 100
        and 0 < p["momentum"] < 100
        and 0 < p["strength"] <= 100
        and p["deviations"] > 0
        and p["volume_ratio"] > 0
        and p["breakout_atr"] >= 0
    ):
        raise ValueError("Invalid strategy settings")
    for k in ("atr_period", "max_positions", "corr_window", "poll_seconds", "history"):
        if type(c[k]) is not int or c[k] < 1:
            raise ValueError(k)
    if not (
        2 <= c["atr_period"]
        and c["corr_window"] >= 3
        and max(
            2 * p["adx"],
            p["slow"] + p["signal"],
            p["channel"],
            p["bands"],
            p["rsi"],
            c["corr_window"],
            c["atr_period"],
        )
        + 3
        <= c["history"]
        <= 500
    ):
        raise ValueError("History must cover indicator warmup and be <=500")
    if not (
        0.005 <= c["risk"] <= 0.01
        and c["reward"] >= 2.5
        and c["atr_stop"] > 0
        and 0 < c["daily_loss"] < 1
        and 0 < c["drawdown"] < 1
        and 0 < c["correlation"] <= 1
        and c["equity"] > 0
        and 0 < c["holdout"] < 1
        and 0 <= c["fee_bps"] < 100
        and 0 <= c["slip_bps"] < 100
    ):
        raise ValueError("Invalid risk, costs or evaluation settings")
    if any(
        not math.isfinite(v)
        for v in [*p.values(), *(v for v in c.values() if isinstance(v, (float, int)))]
    ):
        raise ValueError("Nonfinite parameter")
    if not isinstance(c["symbols"], dict) or not c["symbols"]:
        raise ValueError("symbols maps each instrument to its quantity increment")
    for s, step in c["symbols"].items():
        if not math.isfinite(step) or step <= 0:
            raise ValueError(s)
        parts = s.split("/")
        valid = (
            s.isalnum()
            if c["market"] == "stocks"
            else len(parts) == 2
            and all(x.isalpha() for x in parts)
            and (
                parts[1] in ("USD", "USDT")
                if c["market"] == "crypto"
                else "USD" in parts
            )
        )
        if not valid or s != s.upper():
            raise ValueError(f"Unsupported USD conversion for {s}")
    return c
