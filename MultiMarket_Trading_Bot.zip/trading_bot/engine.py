"""A prior close supplies the signal. Fill at next open, then inspect its range."""

from risk_manager import correlated, fee, limits, plan, result, usd


def mark(c, a, prices):
    return a["balance"] + sum(
        p["qty"] * (usd(s, prices[s] - p["entry"], prices[s]) - fee(c, s, p["entry"]))
        for s, p in a["positions"].items()
    )


def close(c, a, s, price, t, why):
    p = a["positions"].pop(s)
    pnl = result(c, s, p["entry"], price) * p["qty"]
    a["balance"] += pnl
    return dict(
        symbol=s,
        opened=p["opened"],
        closed=str(t),
        qty=p["qty"],
        entry=p["entry"],
        exit=price,
        pnl=pnl,
        reason=why,
    )


def advance(c, a, frames, t, allow_entries=True):
    bars = {s: d.loc[t] for s, d in frames.items()}
    previous = {s: d.iloc[d.index.get_loc(t) - 1] for s, d in frames.items()}
    slip = c["slip_bps"] / 10000
    opens = {s: b.open for s, b in bars.items()}
    limits(c, a, t, mark(c, a, opens))
    trades = []
    exited = set()
    for s, p in list(a["positions"].items()):
        px = opens[s]
        why = (
            "gap_stop"
            if px <= p["stop"]
            else "gap_target"
            if px >= p["target"]
            else "signal"
            if previous[s].exit
            else None
        )
        if why:
            fill = p["target"] if why == "gap_target" else px * (1 - slip)
            trades.append(close(c, a, s, fill, t, why))
            exited.add(s)
    limits(c, a, t, mark(c, a, opens))
    opened = []
    for s, b in bars.items():
        prev = previous[s]
        if not allow_entries or s in exited or s in a["positions"] or not prev.enter:
            continue
        if correlated(c, s, a["positions"], frames, prev.name):
            continue
        free = a["balance"] - sum(
            v["capital"] + v["qty"] * fee(c, k, v["entry"])
            for k, v in a["positions"].items()
        )
        p = plan(c, a, s, b.open * (1 + slip), prev.atr, free)
        if p:
            p["opened"] = str(t)
            a["positions"][s] = p
            opened.append(dict(symbol=s, **p))
            limits(c, a, t, mark(c, a, opens))
    for s, p in list(a["positions"].items()):
        b = bars[s]
        if b.low <= p["stop"]:
            trades.append(close(c, a, s, p["stop"] * (1 - slip), t, "stop"))
        elif b.high >= p["target"]:
            trades.append(close(c, a, s, p["target"], t, "target"))
    prices = {s: b.close for s, b in bars.items()}
    limits(c, a, t, mark(c, a, prices))
    a["cursor"] = str(t)
    return opened, trades
