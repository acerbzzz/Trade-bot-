from functools import lru_cache
import pandas as pd


@lru_cache(maxsize=2)
def client(venue):
    import ccxt

    return getattr(ccxt, venue)(
        {"enableRateLimit": True, "timeout": 15000, "options": {"defaultType": "spot"}}
    )


def bars(c, s, now):
    rows = client(c["venue"]).fetch_ohlcv(s, c["timeframe"], limit=c["history"] + 5)
    d = pd.DataFrame(
        rows, columns=["timestamp", "open", "high", "low", "close", "volume"]
    )
    d["timestamp"] = pd.to_datetime(d.timestamp, unit="ms", utc=True)
    return d
