import json
import os
from urllib.request import Request, urlopen
from urllib.parse import urlencode
import pandas as pd


def api(c, path, method="GET", payload=None):
    domain = "api-fxtrade" if c["mode"] == "live" else "api-fxpractice"
    headers = {
        "Authorization": "Bearer " + os.environ["OANDA_TOKEN"],
        "Content-Type": "application/json",
    }
    req = Request(
        "https://" + domain + ".oanda.com/v3/" + path,
        method=method,
        headers=headers,
        data=json.dumps(payload).encode() if payload is not None else None,
    )
    with urlopen(req, timeout=15) as response:
        return json.load(response)


def bars(c, s, now):
    options = urlencode(
        dict(
            count=c["history"] + 5,
            price="M",
            granularity={"5m": "M5", "15m": "M15", "1h": "H1"}[c["timeframe"]],
        )
    )
    data = api(c, "instruments/" + s.replace("/", "_") + "/candles?" + options)
    return pd.DataFrame(
        [
            dict(
                timestamp=x["time"],
                open=x["mid"]["o"],
                high=x["mid"]["h"],
                low=x["mid"]["l"],
                close=x["mid"]["c"],
                volume=x["volume"],
            )
            for x in data["candles"]
            if x["complete"]
        ]
    )
