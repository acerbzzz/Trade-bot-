import numpy as np
import pandas as pd
from importlib import import_module
from config import MINUTES


def normalize(d):
    d = d.copy()
    if "timestamp" in d:
        d = d.set_index("timestamp")
    d.index = pd.to_datetime(d.index, utc=True)
    d = d[["open", "high", "low", "close", "volume"]].astype(float).sort_index()
    if (
        d.empty
        or d.index.has_duplicates
        or d.index.hasnans
        or not np.isfinite(d.to_numpy()).all()
        or (d.low <= 0).any()
        or (d.volume < 0).any()
        or (d.high < d[["open", "close", "low"]].max(axis=1)).any()
        or (d.low > d[["open", "close"]].min(axis=1)).any()
    ):
        raise ValueError("Invalid or duplicate OHLCV")
    return d


def fetch(c):
    from strategies import prepare

    adapter = import_module("exchange." + c["market"])
    now = pd.Timestamp.now(tz="UTC")
    interval = pd.Timedelta(minutes=MINUTES[c["timeframe"]])
    frames = {}
    for s in c["symbols"]:
        d = normalize(adapter.bars(c, s, now))
        frames[s] = prepare(d.loc[d.index + interval <= now], c)
    return frames
