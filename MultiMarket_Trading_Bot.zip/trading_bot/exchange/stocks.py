import os
from datetime import timedelta
from config import MINUTES


def bars(c, s, now):
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
    from alpaca.data.enums import DataFeed, Adjustment

    client = StockHistoricalDataClient(
        os.environ["APCA_API_KEY_ID"], os.environ["APCA_API_SECRET_KEY"]
    )
    minutes = MINUTES[c["timeframe"]]
    req = StockBarsRequest(
        symbol_or_symbols=s,
        timeframe=TimeFrame(minutes, TimeFrameUnit.Minute)
        if minutes < 60
        else TimeFrame.Hour,
        feed=DataFeed.IEX,
        adjustment=Adjustment.RAW,
        start=(
            now - timedelta(days=int(c["history"] * minutes / 390 * 2) + 12)
        ).to_pydatetime(),
        end=now.to_pydatetime(),
    )
    return client.get_stock_bars(req).df.xs(s).tail(c["history"] + 5)
