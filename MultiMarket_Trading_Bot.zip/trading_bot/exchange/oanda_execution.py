"""Dedicated USD OANDA account. A write intent is committed before network I/O."""

import json
import math
import os
from decimal import Decimal, ROUND_CEILING
from urllib.parse import urlencode
import pandas as pd
from config import MINUTES
from exchange.forex import api
from risk_manager import correlated, limits, plan
from utils.ops import ledger, notify


def account_path():
    return "accounts/" + os.environ["OANDA_ACCOUNT_ID"]


def submit(c, path, t, method, endpoint, payload):
    intent = dict(method=method, endpoint=endpoint, payload=payload, time=str(t))
    with ledger(path, c) as (_, a):
        if a.get("intent"):
            raise RuntimeError(
                "Unresolved broker write; inspect the account and ledger"
            )
        a["intent"] = intent
        a["cursor"] = str(t)
    # Never replay a request with an uncertain outcome.
    res = api(c, endpoint, method, payload)
    if "orderFillTransaction" not in res:
        raise RuntimeError("Broker fill unconfirmed; inspect broker transactions")
    with ledger(path, c) as (db, a):
        a.pop("intent")
        db.execute(
            "INSERT INTO events VALUES(?,?,?)", (str(t), "broker_fill", json.dumps(res))
        )
    notify(c, "Broker fill " + str(res["orderFillTransaction"].get("id")))


def cycle(c, path, frames):
    root = account_path()
    account = api(c, root)["account"]
    trades = account["trades"]
    if account["currency"] != "USD":
        raise RuntimeError("Requires USD account")
    positions = {}
    protection = set()
    for tr in trades:
        s = tr["instrument"].replace("_", "/")
        if (
            s not in frames
            or s in positions
            or float(tr["currentUnits"]) <= 0
            or tr.get("clientExtensions", {}).get("tag") != "modular_bot"
            or not tr.get("stopLossOrderID")
            or not tr.get("takeProfitOrderID")
        ):
            raise RuntimeError("Unexpected account exposure; inspect dedicated account")
        protection.update([tr["stopLossOrderID"], tr["takeProfitOrderID"]])
        positions[s] = tr
    if {o["id"] for o in account["orders"]} != protection:
        raise RuntimeError("Unexpected pending orders")
    latest = {d.index[-1] for d in frames.values()}
    if len(latest) != 1:
        raise ValueError("Market frames are asynchronous")
    t = latest.pop()
    interval = pd.Timedelta(minutes=MINUTES[c["timeframe"]])
    nav = float(account["NAV"])
    if not math.isfinite(nav) or nav <= 0:
        raise ValueError("Invalid NAV")
    with ledger(path, c) as (_, a):
        if a.get("intent"):
            raise RuntimeError("Unresolved broker write; inspect broker transactions")
        if a.get("broker_account", account["id"]) != account["id"]:
            raise RuntimeError("Ledger belongs to another broker account")
        a["broker_account"] = account["id"]
        if a["cursor"] is None:
            a.update(peak=nav, equity=nav, day_start=nav, cursor=str(t))
        a["positions"] = positions
        now = pd.Timestamp.now(tz="UTC")
        limits(c, a, now, nav)
        if a["cursor"] == str(t) or not pd.Timedelta(0) <= now - (
            t + interval
        ) <= pd.Timedelta(seconds=c["poll_seconds"] * 2):
            return
    for s, tr in positions.items():
        if frames[s].iloc[-1].exit:
            submit(
                c,
                path,
                t,
                "PUT",
                root + "/trades/" + tr["id"] + "/close",
                {"units": "ALL"},
            )
            return
    for s, d in frames.items():
        bar = d.iloc[-1]
        if not bar.enter or s in positions or correlated(c, s, positions, frames, t):
            continue
        inst = s.replace("/", "_")
        quote = api(c, root + "/pricing?" + urlencode({"instruments": inst}))["prices"][
            0
        ]
        age = pd.Timestamp.now(tz="UTC") - pd.Timestamp(quote["time"])
        if not quote["tradeable"] or not pd.Timedelta(0) <= age <= pd.Timedelta(
            seconds=10
        ):
            continue
        spec = api(c, root + "/instruments?instruments=" + inst)["instruments"][0]
        tick = Decimal(1).scaleb(-int(spec["displayPrecision"]))

        def price(value, rounding):
            return str(Decimal(str(value)).quantize(tick, rounding=rounding))

        ask = float(quote["asks"][0]["price"])
        bound = price(ask * (1 + c["slip_bps"] / 10000), ROUND_CEILING)
        occupied = sum(
            float(v["currentUnits"])
            * (1 if k.startswith("USD/") else float(v["price"]))
            for k, v in positions.items()
        )
        p = plan(c, a, s, float(bound), bar.atr, max(0, nav - occupied))
        if not p:
            continue
        stop = price(p["stop"], ROUND_CEILING)
        if float(stop) >= float(quote["bids"][0]["price"]):
            continue
        units = int(min(p["qty"], float(spec["maximumOrderUnits"])))
        if units < float(spec["minimumTradeSize"]):
            continue
        order = dict(
            type="MARKET",
            instrument=inst,
            units=str(units),
            timeInForce="FOK",
            priceBound=bound,
            positionFill="OPEN_ONLY",
            tradeClientExtensions={"tag": "modular_bot"},
            stopLossOnFill={"price": stop},
            takeProfitOnFill={"price": price(p["target"], ROUND_CEILING)},
        )
        submit(c, path, t, "POST", root + "/orders", {"order": order})
        return
    with ledger(path, c) as (_, a):
        a["cursor"] = str(t)
