import argparse
import json
import logging
import os
import sys
import time
import pandas as pd
from filelock import FileLock
from config import load, MINUTES
from engine import advance
from exchange import fetch
from utils.ops import ledger, notify, setup


def paper(c, path, frames):
    first = next(iter(frames.values()))
    end = min(d.index[-1] for d in frames.values())
    messages = []
    with ledger(path, c) as (db, a):
        if a["cursor"] is None:
            if not all(end in d.index for d in frames.values()):
                raise ValueError("Missing synchronized start")
            a["cursor"] = str(end)
            logging.info("Paper ledger initialized at %s", end)
            return
        cursor = pd.Timestamp(a["cursor"])
        for d in frames.values():
            if cursor not in d.index:
                raise RuntimeError(
                    "Cursor outside feed history; restore missing data before resuming"
                )
        window = first.loc[cursor:end].index
        if any(not d.loc[cursor:end].index.equals(window) for d in frames.values()):
            raise ValueError(
                "Missing bars across symbols; refusing incomplete portfolio marks"
            )
        for t in window[1:]:
            now = pd.Timestamp.now(tz="UTC")
            age = now - t - pd.Timedelta(minutes=MINUTES[c["timeframe"]])
            fresh = t == end and pd.Timedelta(0) <= age <= pd.Timedelta(
                seconds=2 * c["poll_seconds"]
            )
            opened, closed = advance(c, a, frames, t, allow_entries=fresh)
            for kind, events in [("paper_open", opened), ("paper_close", closed)]:
                for event in events:
                    body = json.dumps(event)
                    db.execute("INSERT INTO events VALUES(?,?,?)", (str(t), kind, body))
                    messages.append(kind + " " + body)
    for message in messages:
        notify(c, message)


def authorize(c):
    if c["mode"] == "paper":
        return
    if c["venue"] != "oanda":
        raise ValueError("Broker execution supported on OANDA only")
    if c["mode"] == "live":
        phrase = "LIVE " + os.environ["OANDA_ACCOUNT_ID"]
        if (
            not sys.stdin.isatty()
            or input(f"Type {phrase} to enable real orders: ") != phrase
        ):
            raise SystemExit("Live confirmation required")


def run(c, once):
    authorize(c)
    path = c.get("state", f"state/{c['venue']}-{c['mode']}.sqlite")
    setup(path)
    from exchange.oanda_execution import cycle

    handler = paper if c["mode"] == "paper" else cycle
    delay = c["poll_seconds"]
    with FileLock(path + ".lock", timeout=0):
        while True:
            try:
                handler(c, path, fetch(c))
                if once:
                    return
                delay = c["poll_seconds"]
            except KeyboardInterrupt:
                return
            except Exception as exc:
                # Network exceptions can contain credential-bearing URLs.
                notify(
                    c,
                    f"Cycle failed ({type(exc).__name__}); entries paused for this cycle.",
                )
                if once:
                    raise
                delay = min(300, max(2, delay * 2))
            time.sleep(delay)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/crypto.yml")
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()
    run(load(args.config), args.once)
