from importlib import import_module
from ta.volatility import AverageTrueRange


def prepare(frame, config):
    d = frame.copy()
    if len(d) < config["history"]:
        raise ValueError("Insufficient warmup history")
    d["atr"] = AverageTrueRange(
        d.high, d.low, d.close, config["atr_period"]
    ).average_true_range()
    strategy = import_module("strategies." + config["strategy"])
    d["enter"], d["exit"] = strategy.signals(d, config["params"])
    return d
