from ta.trend import EMAIndicator, ADXIndicator


def signals(d, p):
    fast = EMAIndicator(d.close, p["fast"]).ema_indicator()
    slow = EMAIndicator(d.close, p["slow"]).ema_indicator()
    adx = ADXIndicator(d.high, d.low, d.close, p["adx"]).adx()
    return (fast > slow) & (fast.shift() <= slow.shift()) & (
        adx >= p["strength"]
    ), fast < slow
