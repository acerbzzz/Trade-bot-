from ta.trend import MACD
from ta.momentum import RSIIndicator


def signals(d, p):
    hist = MACD(d.close, p["slow"], p["fast"], p["signal"]).macd_diff()
    rsi = RSIIndicator(d.close, p["rsi"]).rsi()
    return (hist > 0) & (hist.shift() <= 0) & (rsi >= p["momentum"]), (hist < 0) | (
        rsi < 50
    )
