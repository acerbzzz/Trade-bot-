from ta.volatility import BollingerBands
from ta.momentum import RSIIndicator


def signals(d, p):
    bands = BollingerBands(d.close, p["bands"], p["deviations"])
    rsi = RSIIndicator(d.close, p["rsi"]).rsi()
    return (d.close < bands.bollinger_lband()) & (rsi < p["oversold"]), (
        d.close >= bands.bollinger_mavg()
    ) | (rsi >= p["recovery"])
