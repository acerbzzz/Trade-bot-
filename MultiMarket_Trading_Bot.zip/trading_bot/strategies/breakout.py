def signals(d, p):
    # Both the channel and normal volume exclude the signal candle.
    n = p["channel"]
    top = d.high.shift().rolling(n).max()
    bottom = d.low.shift().rolling(n).min()
    typical = d.volume.shift().rolling(n).mean()
    confirm = (typical > 0) & (d.volume > typical * p["volume_ratio"])
    return (d.close > top + p["breakout_atr"] * d.atr) & confirm, d.close < (
        top + bottom
    ) / 2
