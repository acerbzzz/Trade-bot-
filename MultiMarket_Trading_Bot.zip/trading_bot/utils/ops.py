import json
import logging
import os
import sqlite3
from contextlib import contextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path
from urllib.request import Request, urlopen


def setup(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[
            logging.StreamHandler(),
            RotatingFileHandler(path + ".log", maxBytes=2_000_000, backupCount=3),
        ],
    )


def notify(c, message):
    logging.info(message)
    if c["notify"]:
        try:
            req = Request(
                os.environ["DISCORD_WEBHOOK_URL"],
                data=json.dumps({"content": message[:1900]}).encode(),
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "MultiMarketBot/1",
                },
            )
            with urlopen(req, timeout=5):
                pass
        except Exception as exc:
            logging.warning("Discord delivery failed (%s)", type(exc).__name__)


@contextmanager
def ledger(path, c):
    db = sqlite3.connect(path)
    try:
        db.execute(
            "CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY, settings TEXT, account TEXT)"
        )
        db.execute("CREATE TABLE IF NOT EXISTS events(time TEXT, kind TEXT, data TEXT)")
        row = db.execute("SELECT settings, account FROM state WHERE id=1").fetchone()
        settings = json.dumps(c, sort_keys=True)
        if row and row[0] != settings:
            raise ValueError(
                "Configuration differs from ledger. Restore original config or use a new state path."
            )
        from risk_manager import new_account

        a = json.loads(row[1]) if row else new_account(c)
        yield db, a
        db.execute(
            "INSERT OR REPLACE INTO state VALUES(1,?,?)",
            (settings, json.dumps(a, allow_nan=False)),
        )
        db.commit()
    finally:
        db.close()
