import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
from backtester import demo, evaluate
from bot import authorize, paper
from config import load
from engine import advance
from exchange import normalize
from exchange.oanda_execution import submit
from risk_manager import correlated, limits, new_account, plan, result
from utils.ops import ledger


class Framework(unittest.TestCase):
    def setUp(self):
        self.c = load("configs/crypto.yml")
        self.a = new_account(self.c)
        self.s = next(iter(self.c["symbols"]))
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = self.tmp.name + "/state.db"

    def test_net_risk_reward(self):
        for s in [self.s, "USD/JPY", "EUR/USD"]:
            self.c["symbols"][s] = 0.00001
            p = plan(self.c, self.a, s, 100, 1, 200)
            loss = -result(self.c, s, 100, p["stop"] * (1 - self.c["slip_bps"] / 10000))
            self.assertLessEqual(loss * p["qty"], 1.5)
            self.assertGreaterEqual(
                result(self.c, s, 100, p["target"]) / loss, 2.5 - 1e-9
            )

    def test_no_unfunded_shares(self):
        c = load("configs/stocks.yml")
        self.assertIsNone(plan(c, new_account(c), "SPY", 600, 3, 200))

    def test_circuit_breakers(self):
        limits(self.c, self.a, "2024-01-01", 193)
        limits(self.c, self.a, "2024-01-01", 201)
        self.assertTrue(self.a["day_halt"])
        limits(self.c, self.a, "2024-01-02", 199)
        self.assertFalse(self.a["day_halt"])
        limits(self.c, self.a, "2024-01-02", 170)
        limits(self.c, self.a, "2024-01-03", 210)
        self.assertTrue(self.a["halted"])

    def test_correlation(self):
        f = demo(self.c)
        s, o = f
        f[o] = f[s]
        self.assertTrue(correlated(self.c, s, {o: {}}, f, f[s].index[-1]))
        self.assertTrue(correlated(self.c, s, {o: {}}, f, f[s].index[4]))

    def test_stop_first_and_no_lookahead(self):
        f = demo(self.c)
        d = f[self.s].tail(2).copy()
        d["enter"] = [True, False]
        d["atr"] = 1.0
        d.iloc[-1, d.columns.get_indexer(["open", "low", "high", "close"])] = [
            100,
            70,
            150,
            100,
        ]
        opened, closed = advance(self.c, self.a, {self.s: d}, d.index[-1])
        self.assertAlmostEqual(opened[0]["entry"], 100.03)
        self.assertEqual(closed[0]["reason"], "stop")

    def test_paper_restart(self):
        frames = demo(self.c)
        with ledger(self.path, self.c) as (_, a):
            a["cursor"] = str(frames[self.s].index[-2])
        paper(self.c, self.path, frames)
        paper(self.c, self.path, frames)
        with ledger(self.path, self.c) as (_, a):
            self.assertEqual(a["cursor"], str(frames[self.s].index[-1]))

    def test_configuration_drift(self):
        with ledger(self.path, self.c):
            pass
        with (
            self.assertRaises(ValueError),
            ledger(self.path, self.c | {"strategy": "momentum"}),
        ):
            pass

    def test_unacknowledged_write(self):
        with patch("exchange.oanda_execution.api", side_effect=TimeoutError) as api:
            with self.assertRaises(TimeoutError):
                submit(self.c, self.path, "t", "POST", "orders", {})
            with self.assertRaises(RuntimeError):
                submit(self.c, self.path, "t", "POST", "orders", {})
            self.assertEqual(api.call_count, 1)

    def test_no_unattended_live(self):
        with (
            patch("sys.stdin.isatty", return_value=False),
            patch.dict("os.environ", OANDA_ACCOUNT_ID="sample"),
        ):
            with self.assertRaises(SystemExit):
                authorize(load("configs/forex.yml") | {"mode": "live"})

    def test_all_profiles_and_strategies(self):
        for profile in ["crypto", "stocks", "forex"]:
            for strategy in ["trend", "reversion", "breakout", "momentum"]:
                c = load("configs/" + profile + ".yml") | {"strategy": strategy}
                stats = evaluate(c, demo(c), self.tmp.name)
                self.assertTrue(np.isfinite(stats["final_equity"]))
                self.assertEqual(
                    stats, json.loads(Path(self.tmp.name, "metrics.json").read_text())
                )

    def test_invalid_bars(self):
        d = demo(self.c)[self.s]
        with self.assertRaises(ValueError):
            normalize(pd.concat([d, d.tail(1)]))

    def test_practice_order_is_bounded_protected_and_issued_once(self):
        from exchange.oanda_execution import cycle

        c = load("configs/forex.yml") | {"mode": "practice"}
        now = pd.Timestamp.now(tz="UTC")
        t = now - pd.Timedelta(minutes=15, seconds=1)
        frames = {
            s: pd.DataFrame(
                {"enter": [True], "exit": [False], "atr": [0.001]}, index=[t]
            )
            for s in c["symbols"]
        }
        with ledger(self.path, c) as (_, a):
            a["cursor"] = str(t - pd.Timedelta(minutes=15))
        orders = []

        def fake_api(config, endpoint, method="GET", payload=None):
            if method == "POST":
                orders.append(payload["order"])
                return {"orderFillTransaction": {"id": "7"}}
            if "pricing?" in endpoint:
                return {
                    "prices": [
                        {
                            "time": str(now),
                            "tradeable": True,
                            "asks": [{"price": "1.10001"}],
                            "bids": [{"price": "1.09999"}],
                        }
                    ]
                }
            if "instruments?" in endpoint:
                return {
                    "instruments": [
                        {
                            "displayPrecision": 5,
                            "maximumOrderUnits": "100000",
                            "minimumTradeSize": "1",
                        }
                    ]
                }
            return {
                "account": {
                    "id": "practice-test",
                    "currency": "USD",
                    "NAV": "200",
                    "orders": [],
                    "trades": [],
                }
            }

        with (
            patch.dict("os.environ", OANDA_ACCOUNT_ID="practice-test"),
            patch("exchange.oanda_execution.api", side_effect=fake_api),
        ):
            cycle(c, self.path, frames)
            cycle(c, self.path, frames)
        self.assertEqual(len(orders), 1)
        order = orders[0]
        self.assertLess(
            float(order["stopLossOnFill"]["price"]), float(order["priceBound"])
        )
        self.assertGreater(
            float(order["takeProfitOnFill"]["price"]), float(order["priceBound"])
        )
        self.assertLessEqual(int(order["units"]) * float(order["priceBound"]), 200)
